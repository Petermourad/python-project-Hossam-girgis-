
import requests
import bs4
url='https://aramobi.com/mobile-price/mobile-range/%D8%A3%D9%81%D8%B6%D9%84-%D9%85%D9%88%D8%A8%D8%A7%D9%8A%D9%84-%D8%B4%D8%A7%D9%88%D9%85%D9%8A-%D9%81%D9%8A-%D8%AD%D8%AF%D9%88%D8%AF-4000-%D8%AC%D9%86%D9%8A%D9%87-%D9%85%D8%B5%D8%B1%D9%8A-%D9%84%D8%B9%D8%A7%D9%85-2022/'
page = requests.get(url)
soup = bs4.BeautifulSoup(page.content, "html.parser")
mobiles = soup.find_all('div',{'class':'col-8 col-md-10'})
for i in mobiles:
    print(i.find('a',{'rel':'bookmark'}).getText())
    print(i.find('span', {'class': 'am-screen'}).getText())
    print(i.find('span', {'class': 'am-camera'}).getText())
    print(i.find('span', {'class': 'am-battery'}).getText())
    print()
